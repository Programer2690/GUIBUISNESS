﻿namespace BuisnessProject
{
    partial class optionsAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lbl_name = new System.Windows.Forms.Label();
            this.txt_perfumeName = new System.Windows.Forms.TextBox();
            this.lbl_price = new System.Windows.Forms.Label();
            this.txt_quantity = new System.Windows.Forms.TextBox();
            this.txt_price = new System.Windows.Forms.TextBox();
            this.lbl_quantity = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.btn_back = new System.Windows.Forms.Button();
            this.btn_viewPerfumes = new System.Windows.Forms.Button();
            this.btn_AddPerfume = new System.Windows.Forms.Button();
            this.btn_UpdatePerfume = new System.Windows.Forms.Button();
            this.btn_DeletePerfume = new System.Windows.Forms.Button();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel4, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1219, 680);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.93763F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70.06237F));
            this.tableLayoutPanel2.Controls.Add(this.lbl_name, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.txt_perfumeName, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.lbl_price, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.txt_quantity, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.txt_price, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.lbl_quantity, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 1, 4);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 5;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 64F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(481, 674);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // lbl_name
            // 
            this.lbl_name.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lbl_name.AutoSize = true;
            this.lbl_name.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_name.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_name.Location = new System.Drawing.Point(73, 94);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(68, 24);
            this.lbl_name.TabIndex = 19;
            this.lbl_name.Text = "Name";
            // 
            // txt_perfumeName
            // 
            this.txt_perfumeName.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txt_perfumeName.Location = new System.Drawing.Point(147, 93);
            this.txt_perfumeName.Name = "txt_perfumeName";
            this.txt_perfumeName.Size = new System.Drawing.Size(231, 26);
            this.txt_perfumeName.TabIndex = 20;
            // 
            // lbl_price
            // 
            this.lbl_price.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lbl_price.AutoSize = true;
            this.lbl_price.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold);
            this.lbl_price.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_price.Location = new System.Drawing.Point(80, 147);
            this.lbl_price.Name = "lbl_price";
            this.lbl_price.Size = new System.Drawing.Size(61, 24);
            this.lbl_price.TabIndex = 21;
            this.lbl_price.Text = "Price";
            // 
            // txt_quantity
            // 
            this.txt_quantity.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txt_quantity.Location = new System.Drawing.Point(147, 199);
            this.txt_quantity.Name = "txt_quantity";
            this.txt_quantity.Size = new System.Drawing.Size(231, 26);
            this.txt_quantity.TabIndex = 22;
            // 
            // txt_price
            // 
            this.txt_price.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txt_price.Location = new System.Drawing.Point(147, 146);
            this.txt_price.Name = "txt_price";
            this.txt_price.Size = new System.Drawing.Size(231, 26);
            this.txt_price.TabIndex = 23;
            // 
            // lbl_quantity
            // 
            this.lbl_quantity.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lbl_quantity.AutoSize = true;
            this.lbl_quantity.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold);
            this.lbl_quantity.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_quantity.Location = new System.Drawing.Point(43, 200);
            this.lbl_quantity.Name = "lbl_quantity";
            this.lbl_quantity.Size = new System.Drawing.Size(98, 24);
            this.lbl_quantity.TabIndex = 24;
            this.lbl_quantity.Text = "Quantity";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.btn_back, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.btn_viewPerfumes, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.btn_AddPerfume, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.btn_UpdatePerfume, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.btn_DeletePerfume, 0, 3);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(147, 242);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 5;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(331, 429);
            this.tableLayoutPanel3.TabIndex = 25;
            // 
            // btn_back
            // 
            this.btn_back.AllowDrop = true;
            this.btn_back.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_back.BackColor = System.Drawing.Color.RosyBrown;
            this.btn_back.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold);
            this.btn_back.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_back.Location = new System.Drawing.Point(77, 363);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(177, 43);
            this.btn_back.TabIndex = 20;
            this.btn_back.Text = "Back";
            this.btn_back.UseVisualStyleBackColor = false;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // btn_viewPerfumes
            // 
            this.btn_viewPerfumes.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_viewPerfumes.BackColor = System.Drawing.Color.RosyBrown;
            this.btn_viewPerfumes.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold);
            this.btn_viewPerfumes.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_viewPerfumes.Location = new System.Drawing.Point(77, 21);
            this.btn_viewPerfumes.Name = "btn_viewPerfumes";
            this.btn_viewPerfumes.Size = new System.Drawing.Size(177, 43);
            this.btn_viewPerfumes.TabIndex = 16;
            this.btn_viewPerfumes.Text = "View Perfumes";
            this.btn_viewPerfumes.UseVisualStyleBackColor = false;
            // 
            // btn_AddPerfume
            // 
            this.btn_AddPerfume.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_AddPerfume.BackColor = System.Drawing.Color.RosyBrown;
            this.btn_AddPerfume.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold);
            this.btn_AddPerfume.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_AddPerfume.Location = new System.Drawing.Point(77, 106);
            this.btn_AddPerfume.Name = "btn_AddPerfume";
            this.btn_AddPerfume.Size = new System.Drawing.Size(177, 43);
            this.btn_AddPerfume.TabIndex = 18;
            this.btn_AddPerfume.Text = "Add Perfumes";
            this.btn_AddPerfume.UseVisualStyleBackColor = false;
            this.btn_AddPerfume.Click += new System.EventHandler(this.btn_AddPerfume_Click);
            // 
            // btn_UpdatePerfume
            // 
            this.btn_UpdatePerfume.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_UpdatePerfume.BackColor = System.Drawing.Color.RosyBrown;
            this.btn_UpdatePerfume.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold);
            this.btn_UpdatePerfume.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_UpdatePerfume.Location = new System.Drawing.Point(77, 191);
            this.btn_UpdatePerfume.Name = "btn_UpdatePerfume";
            this.btn_UpdatePerfume.Size = new System.Drawing.Size(177, 43);
            this.btn_UpdatePerfume.TabIndex = 17;
            this.btn_UpdatePerfume.Text = "Update Perfume";
            this.btn_UpdatePerfume.UseVisualStyleBackColor = false;
            this.btn_UpdatePerfume.Click += new System.EventHandler(this.btn_UpdatePerfume_Click);
            // 
            // btn_DeletePerfume
            // 
            this.btn_DeletePerfume.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_DeletePerfume.BackColor = System.Drawing.Color.RosyBrown;
            this.btn_DeletePerfume.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold);
            this.btn_DeletePerfume.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_DeletePerfume.Location = new System.Drawing.Point(77, 276);
            this.btn_DeletePerfume.Name = "btn_DeletePerfume";
            this.btn_DeletePerfume.Size = new System.Drawing.Size(177, 43);
            this.btn_DeletePerfume.TabIndex = 19;
            this.btn_DeletePerfume.Text = "Delete Perfume";
            this.btn_DeletePerfume.UseVisualStyleBackColor = false;
            this.btn_DeletePerfume.Click += new System.EventHandler(this.btn_DeletePerfume_Click);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Controls.Add(this.dataGridView1, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.dataGridView2, 0, 1);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(490, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(726, 674);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(122, 86);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(482, 165);
            this.dataGridView1.TabIndex = 13;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // dataGridView2
            // 
            this.dataGridView2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(108, 411);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 62;
            this.dataGridView2.RowTemplate.Height = 28;
            this.dataGridView2.Size = new System.Drawing.Size(510, 189);
            this.dataGridView2.TabIndex = 14;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // optionsAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BuisnessProject.Properties.Resources.CompressJPEG_online_200kb_45960;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1219, 680);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "optionsAdmin";
            this.Text = "optionsAdmin";
            this.Load += new System.EventHandler(this.optionsAdmin_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.TextBox txt_perfumeName;
        private System.Windows.Forms.Label lbl_price;
        private System.Windows.Forms.TextBox txt_quantity;
        private System.Windows.Forms.TextBox txt_price;
        private System.Windows.Forms.Label lbl_quantity;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button btn_viewPerfumes;
        private System.Windows.Forms.Button btn_UpdatePerfume;
        private System.Windows.Forms.Button btn_AddPerfume;
        private System.Windows.Forms.Button btn_DeletePerfume;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
    }
}