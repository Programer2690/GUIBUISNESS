﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace BuisnessProject
{
    public partial class SignInUp : Form
    {

        public SignInUp(string type)
        {
            InitializeComponent();
            
            if (userDL.readFromFile()&&productDL.readFromFile())
            {
                if (type == "Sign In")
                {
                    btn_SignUp.Visible = false;
                }
                else
                {
                    btn_SignIn.Visible = false;
                }
            }
        }

        private void btn_SIgnUp_Click(object sender, EventArgs e)
        {
            string username = txt_UserName.Text;
            string password = txt_password.Text;
            userBL newuser = new userBL(username, password);
            if (!userDL.validateUser(newuser) && username.ToLower() !="admin" && password.ToLower() !="admin" )
            {
                userDL.AddUsersToList(newuser);
                customerDL.addCustomerLIst((CustomerBL)newuser);
                userDL.StoreInFile();
                MessageBox.Show("User Added SuccessFully");
            }
            else
            {
                MessageBox.Show("Invalid credentials");
            }
        }

        private void btn_SignIn_Click(object sender, EventArgs e)
        {
            string username = txt_UserName.Text;
            string password = txt_password.Text;
            userBL user = new userBL(username, password);
            
            if (password == "admin" && username == "admin")
            {
                Form frm = new Admin();
                frm.Show();
                this.Hide();
                
            }
            else if(userDL.validateUser(user))
            {
                Program.username= username;
                Program.password= password;
                Form form = new CustomerMenu();
                form.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid credentials");
            }

        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form frm = new Form1();
            frm.Show();
            this.Hide();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void SignInUp_Load(object sender, EventArgs e)
        {

        }
    }
}
