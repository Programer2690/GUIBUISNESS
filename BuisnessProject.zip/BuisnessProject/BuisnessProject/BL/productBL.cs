﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuisnessProject
{
    public class productBL
    {
        private string perfume;
        private int price;
        private int quantity;
        public string GetPerfume() { return Perfume; }
        public int GetPrice() { return Price; }
        public int GetQuantity() { return Quantity; }
       

        public productBL(string Perfume, int price, int quantity)
        {
            this.Perfume = Perfume;
            this.Price = price;
            this.Quantity = quantity;
        }
        
        public string toString()
        {
            return "Perfume: " + Perfume + "\tPrice: " + Price + "\tQuantity: " + Quantity;
        }

        

        
        
        public string Perfume { get => perfume; set => perfume = value; }
        public int Price { get => price; set => price = value; }
        public int Quantity { get => quantity; set => quantity = value; }
    }
}
