﻿namespace BuisnessProject
{
    public class userBL
    {
        private string userName;
        private string password;
        public userBL(string username, string password)
        {
            this.userName = username;
            this.password = password;
        }

        

        public string UserName { get => userName; set => userName = value; }
        public string Password { get => password; set => password = value; }


        
    }
}
