﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BuisnessProject
{
    public class CustomerBL : userBL
    {
        public CustomerBL(string username,string password):base(username,password)
        {
           
        }
        public List<productBL> cartList = new List<productBL>();
        public double payableDL()
        {
            double totalPrice = 0;
            foreach (productBL product in cartList)
            {
                totalPrice += product.GetPrice() * product.GetQuantity();
            }
            return totalPrice;
        }


        //public static bool readFromFile()
        //{
        //    string pathProduct = "products.txt";
        //    StreamReader file = new StreamReader(pathProduct);
        //    string record;
        //    if (File.Exists(pathProduct))
        //    {
        //        List<List<string>> list = new List<List<string>>();

        //        while ((record = file.ReadLine()) != null)
        //        {

        //            string[] splittedRecord = record.Split(';');
        //            list[0].Add(splittedRecord[0]);

        //            string perfumeName = splittedRecord[0];
        //            int price = int.Parse(splittedRecord[1]);
        //            int quantity = int.Parse(splittedRecord[2]);
        //            productBL bL = new productBL(perfumeName, price, quantity);
        //            string name = splittedRecord[0];
        //            string value = splittedRecord[1];
        //            foreach (int i in value.Split(':'))
        //            {
        //            }
        //            {
        //                for (int y = 0; y < value.Split(':').Length;)
        //                {
        //                    string a = value[y];

        //                }
        //                perfumeName = splittedRecord[0];
        //                price = int.Parse(splittedRecord[1]);
        //                quantity = int.Parse(splittedRecord[2]);
        //            }
        //            splittedRecord = value.Split(':');
        //            addIntoList(bL);
        //        }
        //        file.Close();
        //        return true;
        //    }
        //    else
        //    {
        //        return false;
        //    }
        //}
        
    }
}
