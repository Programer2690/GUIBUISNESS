﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BuisnessProject
{
    public partial class Admin : Form
    {
        
        public Admin()
        {
            InitializeComponent();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_viewPerfumes_Click(object sender, EventArgs e)
        {
            
            Form frm=new optionsAdmin("view perfumes");
            frm.Show();
            this.Hide();
        }
        

        private void btn_UpdatePerfume_Click(object sender, EventArgs e)
        {
            Form frm = new optionsAdmin("update");
            frm.Show();
            this.Hide();
        }

        private void Admin_Load(object sender, EventArgs e)
        {

        }

        private void btn_AddPerfume_Click(object sender, EventArgs e)
        {
            Form frm = new optionsAdmin("add");
            frm.Show();
            this.Hide();
        }

        private void btn_DeletePerfume_Click(object sender, EventArgs e)
        {
            Form frm = new optionsAdmin("delete");
            frm.Show();
            this.Hide();
        }

        

        private void btn_TotalLogins_Click(object sender, EventArgs e)
        {
            Form frm = new optionsAdmin("login");
            frm.Show();
            this.Hide();
        }

        private void btn_logOut_Click_1(object sender, EventArgs e)
        {
            Form form = new Form1();
            form.Show();
            this.Hide();
        }

        private void btn_wish_Click(object sender, EventArgs e)
        {
            Form frm = new optionsAdmin("wish");
            frm.Show();
            this.Hide();
        }
    }
}
