﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BuisnessProject
{
    public partial class WishForm : Form
    {
        public WishForm()
        {
            InitializeComponent();
        }
        public void databind()
        {
            dataGridView1 = null;
            dataGridView1.DataSource = productDL.wishList;
            dataGridView1.Refresh();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string product = (string)dataGridView1.CurrentRow.DataBoundItem;

        }

        private void WishForm_Load(object sender, EventArgs e)
        {
            databind();
        }
    }
}
