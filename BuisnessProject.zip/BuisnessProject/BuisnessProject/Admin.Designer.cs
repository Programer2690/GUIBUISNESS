﻿namespace BuisnessProject
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btn_logOut = new System.Windows.Forms.Button();
            this.btn_wish = new System.Windows.Forms.Button();
            this.btn_TotalLogins = new System.Windows.Forms.Button();
            this.btn_DeletePerfume = new System.Windows.Forms.Button();
            this.btn_AddPerfume = new System.Windows.Forms.Button();
            this.btn_UpdatePerfume = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_viewPerfumes = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.btn_logOut, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.btn_wish, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.btn_TotalLogins, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.btn_DeletePerfume, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.btn_AddPerfume, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.btn_UpdatePerfume, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_viewPerfumes, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 8;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(563, 596);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // btn_logOut
            // 
            this.btn_logOut.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_logOut.BackColor = System.Drawing.Color.DarkBlue;
            this.btn_logOut.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logOut.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_logOut.Location = new System.Drawing.Point(193, 542);
            this.btn_logOut.Name = "btn_logOut";
            this.btn_logOut.Size = new System.Drawing.Size(177, 43);
            this.btn_logOut.TabIndex = 8;
            this.btn_logOut.Text = "Log Out";
            this.btn_logOut.UseVisualStyleBackColor = false;
            this.btn_logOut.Click += new System.EventHandler(this.btn_logOut_Click_1);
            // 
            // btn_wish
            // 
            this.btn_wish.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_wish.BackColor = System.Drawing.Color.DarkBlue;
            this.btn_wish.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_wish.ForeColor = System.Drawing.Color.GhostWhite;
            this.btn_wish.Location = new System.Drawing.Point(193, 481);
            this.btn_wish.Name = "btn_wish";
            this.btn_wish.Size = new System.Drawing.Size(177, 43);
            this.btn_wish.TabIndex = 6;
            this.btn_wish.Text = "Wish List";
            this.btn_wish.UseVisualStyleBackColor = false;
            this.btn_wish.Click += new System.EventHandler(this.btn_wish_Click);
            // 
            // btn_TotalLogins
            // 
            this.btn_TotalLogins.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_TotalLogins.AutoEllipsis = true;
            this.btn_TotalLogins.BackColor = System.Drawing.Color.DarkBlue;
            this.btn_TotalLogins.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_TotalLogins.ForeColor = System.Drawing.Color.GhostWhite;
            this.btn_TotalLogins.Location = new System.Drawing.Point(193, 422);
            this.btn_TotalLogins.Name = "btn_TotalLogins";
            this.btn_TotalLogins.Size = new System.Drawing.Size(177, 43);
            this.btn_TotalLogins.TabIndex = 5;
            this.btn_TotalLogins.Text = "Total Logins";
            this.btn_TotalLogins.UseVisualStyleBackColor = false;
            this.btn_TotalLogins.Click += new System.EventHandler(this.btn_TotalLogins_Click);
            // 
            // btn_DeletePerfume
            // 
            this.btn_DeletePerfume.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_DeletePerfume.BackColor = System.Drawing.Color.DarkBlue;
            this.btn_DeletePerfume.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DeletePerfume.ForeColor = System.Drawing.Color.GhostWhite;
            this.btn_DeletePerfume.Location = new System.Drawing.Point(193, 363);
            this.btn_DeletePerfume.Name = "btn_DeletePerfume";
            this.btn_DeletePerfume.Size = new System.Drawing.Size(177, 43);
            this.btn_DeletePerfume.TabIndex = 4;
            this.btn_DeletePerfume.Text = "Delete Perfume";
            this.btn_DeletePerfume.UseVisualStyleBackColor = false;
            this.btn_DeletePerfume.Click += new System.EventHandler(this.btn_DeletePerfume_Click);
            // 
            // btn_AddPerfume
            // 
            this.btn_AddPerfume.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_AddPerfume.BackColor = System.Drawing.Color.DarkBlue;
            this.btn_AddPerfume.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddPerfume.ForeColor = System.Drawing.Color.GhostWhite;
            this.btn_AddPerfume.Location = new System.Drawing.Point(193, 304);
            this.btn_AddPerfume.Name = "btn_AddPerfume";
            this.btn_AddPerfume.Size = new System.Drawing.Size(177, 43);
            this.btn_AddPerfume.TabIndex = 3;
            this.btn_AddPerfume.Text = "Add Perfumes";
            this.btn_AddPerfume.UseVisualStyleBackColor = false;
            this.btn_AddPerfume.Click += new System.EventHandler(this.btn_AddPerfume_Click);
            // 
            // btn_UpdatePerfume
            // 
            this.btn_UpdatePerfume.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_UpdatePerfume.BackColor = System.Drawing.Color.DarkBlue;
            this.btn_UpdatePerfume.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_UpdatePerfume.ForeColor = System.Drawing.Color.GhostWhite;
            this.btn_UpdatePerfume.Location = new System.Drawing.Point(193, 245);
            this.btn_UpdatePerfume.Name = "btn_UpdatePerfume";
            this.btn_UpdatePerfume.Size = new System.Drawing.Size(177, 43);
            this.btn_UpdatePerfume.TabIndex = 2;
            this.btn_UpdatePerfume.Text = "Update Perfume";
            this.btn_UpdatePerfume.UseVisualStyleBackColor = false;
            this.btn_UpdatePerfume.Click += new System.EventHandler(this.btn_UpdatePerfume_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Rockwell", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkBlue;
            this.label1.Location = new System.Drawing.Point(175, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(213, 68);
            this.label1.TabIndex = 0;
            this.label1.Text = "Admin";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btn_viewPerfumes
            // 
            this.btn_viewPerfumes.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_viewPerfumes.BackColor = System.Drawing.Color.DarkBlue;
            this.btn_viewPerfumes.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_viewPerfumes.ForeColor = System.Drawing.Color.GhostWhite;
            this.btn_viewPerfumes.Location = new System.Drawing.Point(193, 186);
            this.btn_viewPerfumes.Name = "btn_viewPerfumes";
            this.btn_viewPerfumes.Size = new System.Drawing.Size(177, 43);
            this.btn_viewPerfumes.TabIndex = 1;
            this.btn_viewPerfumes.Text = "View Perfumes";
            this.btn_viewPerfumes.UseVisualStyleBackColor = false;
            this.btn_viewPerfumes.Click += new System.EventHandler(this.btn_viewPerfumes_Click);
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BuisnessProject.Properties.Resources.CompressJPEG_online_200kb_17494;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(563, 596);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Admin";
            this.Text = "Admin";
            this.Load += new System.EventHandler(this.Admin_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_wish;
        private System.Windows.Forms.Button btn_TotalLogins;
        private System.Windows.Forms.Button btn_DeletePerfume;
        private System.Windows.Forms.Button btn_AddPerfume;
        private System.Windows.Forms.Button btn_UpdatePerfume;
        private System.Windows.Forms.Button btn_viewPerfumes;
        private System.Windows.Forms.Button btn_logOut;
    }
}