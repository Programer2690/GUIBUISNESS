﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BuisnessProject
{
    public partial class CustomerMenu : Form
    {
        
        public CustomerMenu()
        {
            InitializeComponent();
        }

        private void CustomerMenu_Load(object sender, EventArgs e)
        {

        }

        private void btn_viewProduct_Click(object sender, EventArgs e)
        {           
            Form frm = new customerOptions("view");
            frm.Show();
            this.Hide();
        }

        private void btn_cart_Click(object sender, EventArgs e)
        {
            Form frm = new customerOptions("cart");
            frm.Show();
            this.Hide();
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            Form form = new Form1();
            form.Show();
            this.Hide();
            customerDL.cartList.Clear();
        }

        private void btn_payable_Click(object sender, EventArgs e)
        {
            Form frm = new customerOptions("pay");
            frm.Show();
            this.Hide();
        }

        private void btn_wish_Click(object sender, EventArgs e)
        {
            Form frm = new WishForm();
            frm.Show();
            this.Hide();
        }
    }
}
