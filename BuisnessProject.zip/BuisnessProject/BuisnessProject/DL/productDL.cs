﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuisnessProject
{
    public class productDL
    {
      
        public static List<productBL> products = new List<productBL>();
        public static List<string> wishList = new List<string>();

        public static void addIntoList(productBL s)
        {
            products.Add(s);
        }
        public static void StoreInFileProducts()
        {
            string path = "products.txt";
            StreamWriter file = new StreamWriter(path, false);
            foreach (productBL productBL in products)
            {
                file.WriteLine(productBL.GetPerfume() + "," + productBL.GetPrice() + "," + productBL.GetQuantity());
                file.Flush();
            }
            file.Close();
        }
        public static bool readFromFile()
        {
            string pathProduct = "products.txt";
            StreamReader file = new StreamReader(pathProduct);
            string record;
            if (File.Exists(pathProduct))
            {
                while ((record = file.ReadLine()) != null)
                {
                    string[] splittedRecord = record.Split(',');
                    string perfumeName = splittedRecord[0];
                    int price = int.Parse(splittedRecord[1]);
                    int quantity = int.Parse(splittedRecord[2]);
                    productBL bL = new productBL(perfumeName, price, quantity);
                    addIntoList(bL);
                }
                file.Close();
                return true;
            }
            else
            {
                return false;
            }
        }
        
    }
}