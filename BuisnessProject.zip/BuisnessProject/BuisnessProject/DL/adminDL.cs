﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuisnessProject.DL
{
    public class adminDL
    {
        public static void deleteDL(string perfume)
        {
            foreach (productBL i in productDL.products)
            {
                if (perfume == i.GetPerfume())
                {
                    productDL.products.Remove(i);
                    break;
                }              
            }
        }
        public static productBL checkPerfume(string perfumeName)
        {
            foreach (productBL product in productDL.products)
            {
                if (product.GetPerfume() == perfumeName)
                {
                    return product;
                }
            }
            return null;
        }
    }
}
