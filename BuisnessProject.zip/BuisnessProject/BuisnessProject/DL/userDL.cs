﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuisnessProject
{
    public class userDL
    {
        public static List<userBL> usersList = new List<userBL>();
        public static bool validateUser(userBL user)
        {
            if (usersList.Contains(user))
            { return true; }
            return false;
        }
        public static void AddUsersToList(userBL s)
        {
            usersList.Add(s);
        }
        
        public static void StoreInFile()
        {
            string path = "users.txt";
            StreamWriter file = new StreamWriter(path, true);
            foreach (userBL bL in usersList)
            {
                file.WriteLine(bL.UserName + "," + bL.Password + ",");
                file.Flush();
            }
            file.Close();
        }
        public static bool readFromFile()
        {
            string path = "users.txt";
            StreamReader file = new StreamReader(path);
            string record;
            if (File.Exists(path))
            {
                while ((record = file.ReadLine()) != null)
                {
                    string[] splittedRecord = record.Split(',');
                    string userName = splittedRecord[0];
                    string password = splittedRecord[1];

                    userBL bL = new userBL(userName, password);
                    AddUsersToList(bL);
                }
                file.Close();
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
