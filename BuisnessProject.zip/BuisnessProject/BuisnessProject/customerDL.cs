﻿using System.Collections.Generic;
using System.IO;

namespace BuisnessProject
{
    public class customerDL
    {
        public static List<CustomerBL> customerList = new List<CustomerBL>();
        public static List<productBL> cartList = new List<productBL>();
        public static void addCustomerLIst(CustomerBL customerBL)
        {
            customerList.Add(customerBL);
        }
        public static void storeCustomersDataInFile()
        {
            string path = "customer.txt";
            if (File.Exists(path))
            {
                StreamWriter fileVariable = new StreamWriter(path);

                fileVariable.Write(Program.username + "," + Program.password + ",");
                int len = cartList.Count - 1;
                int j = 0;
                foreach (var i in cartList)
                {
                    if (j < len)
                        fileVariable.Write(i.GetPerfume() + ";" + i.GetQuantity() + ";" + i.GetPrice() + ":");
                    else if (j == len)
                        fileVariable.Write(i.GetPerfume() + ";" + i.GetQuantity() + ";" + i.GetPrice());
                    j++;
                }

                fileVariable.WriteLine();
                fileVariable.Flush();
                fileVariable.Close();
            }
        }
        public static void deleteDL(string perfume)
        {
            foreach (productBL i in cartList)
            {
                if (perfume == i.GetPerfume())
                {
                    productDL.products.Remove(i);
                    break;
                }
            }
        }
        public static int payable()
        {
            int total = 0;
            foreach(var product in cartList)
            {
                total += product.Quantity * product.Price;
            }
            return total;
        }
    }
}
