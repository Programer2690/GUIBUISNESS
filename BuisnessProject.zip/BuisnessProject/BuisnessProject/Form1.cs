﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BuisnessProject
{
    public partial class Form1 : Form
    {
        string type;
        public Form1()
        {
            InitializeComponent();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            type = "Sign Up";
            Form frm = new SignInUp(type);
            frm.Show();
            this.Hide();
        }

        private void btn_signIn_Click(object sender, EventArgs e)
        {
            type = "Sign In";
            Form frm = new SignInUp(type);
            frm.Show();
            this.Hide();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
