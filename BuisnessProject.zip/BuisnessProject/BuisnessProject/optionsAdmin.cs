﻿using BuisnessProject.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BuisnessProject
{
    public partial class optionsAdmin : Form
    {
                
        public optionsAdmin(string type)
        {
            InitializeComponent();

            if(type == "view perfumes") 
            {
                lbl_name.Hide();
                lbl_price.Hide();
                lbl_quantity.Hide();
                txt_perfumeName.Hide();
                txt_price.Hide();   
                txt_quantity.Hide();
                btn_viewPerfumes.Hide();
                btn_UpdatePerfume.Hide();
                btn_DeletePerfume.Hide();
                btn_AddPerfume.Hide();
                dataGridView2.Hide();
            }
            else if (type == "update")
            {
                btn_DeletePerfume.Hide();
                btn_AddPerfume.Hide();
                btn_viewPerfumes.Hide();
                dataGridView2.Hide();
            }
            else if (type == "add")
            {
                btn_UpdatePerfume.Hide();
                btn_DeletePerfume.Hide();
                btn_viewPerfumes.Hide();
                dataGridView2.Hide();
            }
            else if(type == "login"){
                btn_UpdatePerfume.Hide();
                btn_AddPerfume.Hide();
                btn_viewPerfumes.Hide();
                dataGridView1.Hide();
            }
            else 
            {
                btn_UpdatePerfume.Hide();
                btn_AddPerfume.Hide();
                btn_viewPerfumes.Hide();
                dataGridView2.Hide();
            }
            databind();
            Databind();
        }
        private void databind()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = productDL.products;
            dataGridView1.Refresh();
        }
        private void Databind()
        {
            dataGridView2.DataSource = null;
            dataGridView2.DataSource = userDL.usersList;
            dataGridView2.Refresh();
        }
        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void optionsAdmin_Load(object sender, EventArgs e)
        {
            databind();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form frm = new Admin();
            frm.Show();
            this.Hide();
        }

        
        private void btn_AddPerfume_Click(object sender, EventArgs e)
        {
            
            string Name = txt_perfumeName.Text;
            int price = int.Parse(txt_price.Text);
            int quantity= int.Parse(txt_quantity.Text);
                productBL productBL = new productBL(Name, price, quantity);
                if (adminDL.checkPerfume(Name) == null)
                {
                    productDL.addIntoList(productBL);
                    databind();
                    MessageBox.Show("added successfully");
                    productDL.StoreInFileProducts();
                }
                else
                {
                    MessageBox.Show("Already Exists");
                }                       
        }

        private void btn_UpdatePerfume_Click(object sender, EventArgs e)
        {
            string Name = txt_perfumeName.Text;
            int price = int.Parse(txt_price.Text);
            int quantity = int.Parse(txt_quantity.Text);                       
                if (adminDL.checkPerfume(Name) != null)
                {
                    productBL product = adminDL.checkPerfume(Name);
                    product.Price = price;
                    product.Quantity = quantity;
                    product.Perfume = Name;
                    productDL.StoreInFileProducts();
                databind();
                }            
        }

        private void btn_DeletePerfume_Click(object sender, EventArgs e)
        {
            string name = txt_perfumeName.Text;
            adminDL.deleteDL(name);
            productDL.StoreInFileProducts();
            databind();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            userBL p = (userBL)dataGridView2.CurrentRow.DataBoundItem;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            productBL p = (productBL)dataGridView1.CurrentRow.DataBoundItem;
            txt_perfumeName.Text = p.Perfume;
            txt_price.Text = p.Price.ToString();
            txt_quantity.Text = p.Quantity.ToString();
        }
    }
}
