﻿namespace BuisnessProject
{
    partial class CustomerMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_viewProduct = new System.Windows.Forms.Button();
            this.btn_cart = new System.Windows.Forms.Button();
            this.btn_payable = new System.Windows.Forms.Button();
            this.btn_logout = new System.Windows.Forms.Button();
            this.btn_wish = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_viewProduct, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.btn_cart, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.btn_payable, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.btn_wish, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.btn_logout, 0, 5);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(697, 677);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Rockwell", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Peru;
            this.label1.Location = new System.Drawing.Point(198, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(300, 68);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer";
            // 
            // btn_viewProduct
            // 
            this.btn_viewProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_viewProduct.BackColor = System.Drawing.Color.PeachPuff;
            this.btn_viewProduct.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_viewProduct.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_viewProduct.ForeColor = System.Drawing.Color.DarkOrange;
            this.btn_viewProduct.Location = new System.Drawing.Point(261, 161);
            this.btn_viewProduct.Name = "btn_viewProduct";
            this.btn_viewProduct.Size = new System.Drawing.Size(175, 49);
            this.btn_viewProduct.TabIndex = 1;
            this.btn_viewProduct.Text = "View Perumes";
            this.btn_viewProduct.UseVisualStyleBackColor = false;
            this.btn_viewProduct.Click += new System.EventHandler(this.btn_viewProduct_Click);
            // 
            // btn_cart
            // 
            this.btn_cart.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_cart.BackColor = System.Drawing.Color.PeachPuff;
            this.btn_cart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cart.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cart.ForeColor = System.Drawing.Color.DarkOrange;
            this.btn_cart.Location = new System.Drawing.Point(261, 262);
            this.btn_cart.Name = "btn_cart";
            this.btn_cart.Size = new System.Drawing.Size(175, 49);
            this.btn_cart.TabIndex = 2;
            this.btn_cart.Text = "View Cart";
            this.btn_cart.UseVisualStyleBackColor = false;
            this.btn_cart.Click += new System.EventHandler(this.btn_cart_Click);
            // 
            // btn_payable
            // 
            this.btn_payable.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_payable.BackColor = System.Drawing.Color.PeachPuff;
            this.btn_payable.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_payable.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_payable.ForeColor = System.Drawing.Color.DarkOrange;
            this.btn_payable.Location = new System.Drawing.Point(261, 363);
            this.btn_payable.Name = "btn_payable";
            this.btn_payable.Size = new System.Drawing.Size(175, 49);
            this.btn_payable.TabIndex = 3;
            this.btn_payable.Text = "Payable";
            this.btn_payable.UseVisualStyleBackColor = false;
            this.btn_payable.Click += new System.EventHandler(this.btn_payable_Click);
            // 
            // btn_logout
            // 
            this.btn_logout.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_logout.BackColor = System.Drawing.Color.PeachPuff;
            this.btn_logout.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_logout.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logout.ForeColor = System.Drawing.Color.DarkOrange;
            this.btn_logout.Location = new System.Drawing.Point(261, 583);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(175, 49);
            this.btn_logout.TabIndex = 4;
            this.btn_logout.Text = "Log Out";
            this.btn_logout.UseVisualStyleBackColor = false;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // btn_wish
            // 
            this.btn_wish.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_wish.BackColor = System.Drawing.Color.PeachPuff;
            this.btn_wish.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_wish.Font = new System.Drawing.Font("Rockwell", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_wish.ForeColor = System.Drawing.Color.DarkOrange;
            this.btn_wish.Location = new System.Drawing.Point(261, 464);
            this.btn_wish.Name = "btn_wish";
            this.btn_wish.Size = new System.Drawing.Size(175, 49);
            this.btn_wish.TabIndex = 5;
            this.btn_wish.Text = "Wish List";
            this.btn_wish.UseVisualStyleBackColor = false;
            this.btn_wish.Click += new System.EventHandler(this.btn_wish_Click);
            // 
            // CustomerMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BuisnessProject.Properties.Resources.CompressJPEG_online_200kb_181773;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(697, 677);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "CustomerMenu";
            this.Text = "CustomerMenu";
            this.Load += new System.EventHandler(this.CustomerMenu_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_viewProduct;
        private System.Windows.Forms.Button btn_cart;
        private System.Windows.Forms.Button btn_payable;
        private System.Windows.Forms.Button btn_logout;
        private System.Windows.Forms.Button btn_wish;
    }
}