﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BuisnessProject
{
    public partial class customerOptions : Form
    {
        public static int payable = customerDL.payable();
        
        string perfumeName;
        int price;
        int quantity;
        public customerOptions(string type)
        {
            InitializeComponent();
            if (type == "view")
            {

                btn_viewPerfumes.Hide();
                dataGridView2.Hide();
                btn_RemoveFromCart.Hide();
                btn_Confirm_order.Hide();
            }
            else if (type == "cart")
            {
                dataGridView1.Hide();
                btn_AddToCart.Hide();
            }
            else if (type == "pay")
            {
                dataGridView1.Hide();
                btn_AddToCart.Hide();
                btn_RemoveFromCart.Hide();
                btn_viewPerfumes.Hide();
                lbl_name.Hide();
                lbl_quantity.Hide();
                txt_perfumeName.Hide();
                txt_quantity.Hide();
                btn_Confirm_order.Hide();
                txt_price.Text = customerDL.payable().ToString();
            }
            
            }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void customerOptions_Load(object sender, EventArgs e)
        {
            databind();
            DataBind();
        }
        private void databind()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = productDL.products;
            dataGridView1.Refresh();
        }
        private void DataBind()
        {
            dataGridView2.DataSource = null;
            dataGridView2.DataSource = customerDL.cartList;
            dataGridView2.Refresh();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            productBL p = (productBL)dataGridView1.CurrentRow.DataBoundItem;
            txt_perfumeName.Text = p.Perfume;    
            txt_price.Text=p.Price.ToString();
            txt_quantity.Text = p.Quantity.ToString();
        }

        private void btn_AddToCart_Click(object sender, EventArgs e)
        {
            productBL p = (productBL)dataGridView1.CurrentRow.DataBoundItem;
            perfumeName = txt_perfumeName.Text;
            price = p.Price;
            quantity=int.Parse( txt_quantity.Text);
            productBL product=new productBL(perfumeName, price, quantity);
            if(quantity <=p.Quantity) 
            {
               p.Quantity= p.Quantity - quantity;
                
               customerDL.cartList.Add(product);
                DataBind();
                databind();
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            productBL product=(productBL)dataGridView2.CurrentRow.DataBoundItem;
            txt_perfumeName.Text=product.Perfume;
            txt_price.Text=product.Price.ToString();
            txt_quantity.Text=product.Quantity.ToString();
        }
        private void btn_RemoveFromCart_Click(object sender, EventArgs e)
        {
            string name = txt_perfumeName.Text;
            customerDL.deleteDL(name);
            customerDL.storeCustomersDataInFile();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form form = new CustomerMenu();
            form.Show();
            this.Hide();
        }

        private void Confirm_order_Click(object sender, EventArgs e)
        {
            MessageBox.Show("we have confirmed your order which will be delieverd soon!");
            Form form = new CustomerMenu();
            form.Show();
            this.Hide();

        }
    }
}
